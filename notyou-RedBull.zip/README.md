# Details
Made this as a first mod to learn modding. None of the assets or branding are mine so this will be deleted eventually.

Changelog:

2.1.0 - Removed all of the unused files from the asset bundle and renamed mod from Red_Bull to RedBull.